module.exports = {
    client: 'mysql',
    connection: {
        user: 'root',
        password: 'password',
        database: 'products',
        host: 'db'
    }
}