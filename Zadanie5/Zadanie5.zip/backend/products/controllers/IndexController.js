exports.home = (req, res) => {
    res.json({'status':'working very well!'});
}