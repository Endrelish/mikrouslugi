const products = [
    {
        id:1,
        name:"Lenovo T520",
        description: "Good laptop",
        price: 4000,
        amount: 3
    }
]

module.exports = products;